import info
from pathlib import Path

def save(title,stars,quick,long,img):
    filename = info.folder + title + ".jr"
    with open(filename,"w") as f:
        f.write(f"{stars}|{quick}|{long}|{img}")
def read(title):
    if not Path(f"{info.folder}{title}.jr").exists():
        return None
    with open(f"{info.folder}{title}.jr","r") as f:
        stars, quick, long, img = f.read().split("|")
        return stars, quick, long, img
