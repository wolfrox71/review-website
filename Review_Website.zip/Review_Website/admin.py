class database:
    default_saved = ""
    default_role = "user"
    roles = ["user","admin"]
    admin_roles = ["admin"]
    yes_ans = ["yes","y"]
class reviews:
    consoles = ["playstation","xbox","switch","pc","mobile"]
    age_ratings = ["7","12","15"]