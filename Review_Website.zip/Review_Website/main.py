from flask import Flask, redirect, url_for, render_template, request, session, flash
from datetime import timedelta, datetime
import database, admin
import sqlite3
import hashlib
import writer

conn = sqlite3.connect("main.db",check_same_thread=False)
c = conn.cursor()

app = Flask(__name__)
app.secret_key = "something to say about nothing"
app.permanent_session_lifetime = timedelta(minutes=5)

users_db = database.db("main.db","users")
users_db.setup("username","password","saved","role")

reviews_db = database.db("main.db","reviews")
reviews_db.setup("game","age","stars","short","full","xbox","playstation","switch","pc","mobile","image")

def hash(str):
    salt = "2d1133dd810c6ca8e84118c79545847b"
    hashed = hashlib.md5(str.encode()+salt.encode())
    return hashed.hexdigest()

def get_redirect():
    if "redirect" not in session:
        session["redirect"] = None

    if session["redirect"] is not None:
        redirect = session["redirect"]
        session["redirect"] = None
        return url_for(redirect)
    return None

@app.route("/")
@app.route("/home/")
def home():
    url = get_redirect()
    if url is not None:
        return redirect(url)
    if "username" in session and "password" in session:
        return render_template("/user/home.html", values=[session["username"],session["password"]]) 
    return redirect(url_for("login"))

@app.route("/create_user/",methods=["POST","GET"])
def create_user():
    if "username" not in session:
        return redirect(url_for("login"))
    if request.method == "POST":
        if request.form["create_user"] == "yes":
            print(session["username"],session["password"])
            session["role"] = admin.database.default_role
            users_db.insert(session["username"],session["password"],admin.database.default_saved,admin.database.default_role)
            return redirect(url_for('home'))
        if request.form["create_user"] == "no":
            return redirect(url_for("logout"))
    return render_template("user/create_user.html")

@app.route("/login/", methods=["POST","GET"])
def login():
    if request.method == "POST":
        username = request.form["name"]
        password = hash(request.form["password"])
        c.execute("SELECT role FROM users WHERE username =:username AND password =:password",
        {"username":username,"password":password})
        session["username"] = username
        session["password"] = password
        output = c.fetchall()
        if len(output) == 0:
            return redirect(url_for("create_user"))
        session["role"] = output[0][0]
        return redirect(url_for("home"))

    return render_template("user/login.html")

@app.route("/logout/")
def logout():
    to_del = dict(session)
    for x in to_del:
        session.pop(x)
    return redirect(url_for("home"))

@app.route("/user/")
def user_home():
    return redirect(url_for("user_update"))

@app.route("/user/update")
def user_update():
    return render_template("/user/update/home.html")

@app.route("/user/update/password", methods=["POST","GET"])
def user_update_password():
    if "username" not in session:
        session["redirect"] = "user_update_password"
        return redirect(url_for("login"))
    if request.method == "POST":
        if "current" not in request.form:
            return render_template("/user/update/password.html",message="")

        if hash(request.form["current"]) == session["password"]:
            c.execute("UPDATE users SET password=:new_password WHERE username =:username and password =:password",{
                "new_password":hash(request.form["new1"]), "password":session["password"],"username":session["username"] 
            })
            conn.commit()
            session["password"] = hash(request.form["new1"])
            return redirect(url_for("home"))
        else:
            return render_template("/user/update/password.html",message="Entered Current Password Is Incorrect")  
    return render_template("/user/update/password.html")

@app.route("/user/update/role", methods=["POST","GET"])
def user_update_role():
    if "username" not in session:
        session["redirect"] = "user_update_role"
        return redirect(url_for("login"))
    if request.method == "POST":
        c.execute("UPDATE users SET role=:new_role WHERE username =:username and password =:password",{
            "new_role":request.form["role"], "password":session["password"],"username":session["username"] 
        })
        conn.commit()
        session["role"] = hash(request.form["role"])
        return redirect(url_for("home"))
    return render_template("/user/update/role.html", values=admin.database.roles)


@app.route("/users/")
def users():
    return render_template("/users/home.html")

@app.route("/users/view/")
def users_view():
    return render_template("/users/view.html", values=users_db.read())

@app.route("/users/delete/", methods=["POST","GET"])
def users_delete():
    if "username" not in session:
        session["redirect"] = "users_delete"
        return redirect(url_for("login"))
    if session["role"] in admin.database.admin_roles:
        return redirect(url_for("users_delete_admin"))
    if request.method == "POST":
        if request.form["answer"] == "yes":
            c.execute("DELETE FROM users WHERE username=:username AND password=:password",{
                "username":session["username"], "password":session["password"]
            })
            conn.commit()
            return redirect(url_for("logout"))
        return redirect(url_for("home"))
    return render_template("/user/delete/user.html")

@app.route("/users/delete/admin/", methods=["POST","GET"])
def users_delete_admin():
    if "username" not in session:
        session["redirect"] = "users_delete_admin"
        return redirect(url_for("login"))
    if session["role"] not in admin.database.admin_roles:
        return redirect(url_for("users_delete"))
    if request.method == "POST":
        username, password = request.form["del_user"].split("¦|")
        c.execute("DELETE FROM users WHERE username=:username AND password=:password",
        {"username":username,"password":password})
        conn.commit()
        return redirect(url_for("users_view"))
    return render_template("/user/delete/admin.html",values=users_db.read())

@app.route("/database/")
def database_home():
    return render_template("/database/home.html")

@app.route("/database/setup/")
def database_setup():
    users_db.setup()
    return redirect(url_for("login"))

@app.route("/database/clear/", methods=["POST","GET"])
def database_clear():
    if request.method == "POST":
        if request.form["answer"] in admin.database.yes_ans:
            if session["role"] in admin.database.admin_roles:
                users_db.clear()
                return redirect(url_for("logout"))

    if "username" not in session:
        session["redirect"] = "database_clear"
        return redirect(url_for("login"))
    
    return render_template("/database/clear.html")

@app.route("/reviews/",methods=["POST","GET"])
def reviews():
    if request.method == "POST":
        age = request.form["age"]
        console = request.form["console"]
        search = request.form["search"].lower()
        if (len(search)) != 0:
            c.execute("SELECT * FROM reviews WHERE game LIKE :search",{"search":str(search)+"%"})
        elif age == "None" and console != "None":
            to_run = "SELECT * FROM reviews WHERE "+ str(console) + "='True'"
            c.execute(to_run)
        elif age != "None" and console == "None":
            c.execute("SELECT * FROM reviews WHERE age=:age",{"age":str(age)})
        elif age != "None" and console != "None":
            to_run = "SELECT * FROM reviews WHERE "+ str(console) + "='True' AND age=" + str(age)
            c.execute(to_run)
        else:
            return redirect(url_for("reviews"))
        conn.commit()
        #c.execute("SELECT * FROM reviews WHERE playstation='True'")
        return render_template("/reviews/results.html",values=c.fetchall())
    else:
        return render_template("/reviews/home.html",consoles=admin.reviews.consoles,ages=admin.reviews.age_ratings)

@app.route("/reviews/results",methods=["POST","GET"])
def results_review():
    if request.method=="POST":
        return redirect("/reviews/game/"+request.form["game"].lower())
    return redirect(url_for("reviews"))

@app.route("/reviews/create/",methods=["POST","GET"])
def add_review():
    if "username" not in session:
        session["redirect"] = "add_review"
        return redirect(url_for("login"))
    if session["role"] not in admin.database.admin_roles:
        return redirect(url_for("reviews"))
    if request.method == "POST":
        duplicates = False
        for x in reviews_db.read():
            if x[0] == request.form["game"].lower():
                duplicates = True
        if not duplicates:
            reviews_db.insert(request.form["game"].lower(), request.form["age"], request.form["stars"],request.form["short"], request.form["full"], request.form["xbox"], request.form["playstation"], request.form["switch"],request.form["pc"],request.form["mobile"],request.form["image"])
        
        return redirect(url_for("reviews"))
    else:
        return render_template("/reviews/add.html",consoles=admin.reviews.consoles, ages = admin.reviews.age_ratings)

@app.route("/reviews/clear/")
def clear_review():
    if "username" not in session:
        session["redirect"] = "clear_review"
        return redirect(url_for("login"))
    if session["role"] not in admin.database.admin_roles:
        return redirect(url_for("reviews"))
    reviews_db.clear()
    return """
    <p>Database cleared</p>
    <a href="/">Home</a>"""

@app.route("/reviews/game/<game>")
def game_reviews(game):
    print(game)
    c.execute("SELECT * FROM reviews WHERE game=:game", {"game":game.lower()})
    result = c.fetchone()
    if result is None:
        return """<p>Review not found</p>
        <a href="/reviews/">Reviews</a>"""
    return render_template("/reviews/review.html",values=result)

@app.route("/reviews/list/")
def list_review():
    return render_template("/reviews/view.html",values=reviews_db.read())

@app.route("/reviews/delete",methods=["POST","GET"])
def delete_review():
    if request.method == "POST":
        reviews_db.remove(request.form["game"].lower(),1)
        return redirect(url_for("list_review"))
    return render_template("/reviews/delete.html",values=reviews_db.read())

if __name__ == "__main__":
    app.run(debug=True)
    #app.run(host="0.0.0.0")